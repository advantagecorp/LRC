// This script was generated and reflects raw data. It is recommended to change this code to your required logic
load.initialize(async function () {
    load.log("Script : " + load.config.script.name + " ; VU : " + load.config.script.userId);
});



load.action("Action", async function () {

    load.log("Action");

    var username = load.params.user;
    var password = load.params.password;
    load.log("Iteration : " + load.config.runtime.iteration + " ; UserName : " + username + " ; Password : " + password);

    

    load.WebRequest.defaults.returnBody = false;
    load.WebRequest.defaults.headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
        "Accept-Encoding": "gzip, deflate",
        "Accept-Language": "fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
        "Pragma": "no-cache",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36"
    };

    const HTMLTitle = new load.RegexpExtractor("HTMLTitle", {
 expression: "<title>(.*?)</title>",
 flags: "i",
 groupNumber: -1
 } );
    const sessionid = new load.BoundaryExtractor("sessionid","JSESSIONID=",";");

    const webResponse1 = new load.WebRequest({
        id: 1,
        url: "http://demo.borland.com/",
        method: "GET"
    }).sendSync();

    // To use correlation rule: `${webResponse2.correlations.sessionid}` 
    const webResponse2 = new load.WebRequest({
        id: 2,
        url: "http://demo.borland.com/InsuranceWebExtJS/",
        method: "GET",
        headers: {
            "Referer": "http://demo.borland.com/"
        },
        resources: [
            "http://demo.borland.com/InsuranceWebExtJS/images/h_back2.jpg",
            "http://demo.borland.com/InsuranceWebExtJS/images/header.png",
            "http://demo.borland.com/InsuranceWebExtJS/images/signup.gif;jsessionid=96CCB0940121358F121D148259E7D0EA",
            "http://demo.borland.com/InsuranceWebExtJS/images/login.gif;jsessionid=96CCB0940121358F121D148259E7D0EA",
            "http://demo.borland.com/InsuranceWebExtJS/javascript/menu.js",
            "http://demo.borland.com/InsuranceWebExtJS/css/style.css",
            "http://demo.borland.com/InsuranceWebExtJS/images/tiles.png"
        ],
        extractors: [
            sessionid //"96CCB0940121358F121D148259E7D0EA"
        ]
    }).sendSync();



    const Login = new load.Transaction("Login");
    Login.start();

    // To use correlation rule: `${webResponse3.correlations.HTMLTitle}` 
    const MSGError = new load.BoundaryExtractor("messageerror", "class=\"message-error\"><td>", "</td>");
    const LoggedInAs = new load.BoundaryExtractor("loggedinas", "<p>Logged in as</p> <label for=\"logout-form\" class=\"login\>", "</label>");
    const webResponse3 = new load.WebRequest({
        id: 3,
        //url: "http://demo.borland.com/InsuranceWebExtJS/index.jsf;jsessionid=96CCB0940121358F121D148259E7D0EA",
        url: "http://demo.borland.com/InsuranceWebExtJS/index.jsf;jsessionid=" + `${webResponse2.extractors.sessionid}`,
        method: "POST",
        headers: {
            "Referer": "http://demo.borland.com/InsuranceWebExtJS/",
            "Content-Type": "application/x-www-form-urlencoded",
            "Origin": "http://demo.borland.com"
        },
        resources: [
            "http://demo.borland.com/InsuranceWebExtJS/images/h_back2.jpg",
            "http://demo.borland.com/InsuranceWebExtJS/images/header.png",
            "http://demo.borland.com/InsuranceWebExtJS/images/tiles.png",
            "http://demo.borland.com/InsuranceWebExtJS/javascript/menu.js",
            "http://demo.borland.com/InsuranceWebExtJS/css/style.css"
        ],
        body: {
            "login-form": "login-form",
            "login-form:email": `${username}`, //"john.smith@gmail.com",
            "login-form:password": `${password}`, //"john",
            "login-form:login.x": "42",
            "login-form:login.y": "13",
            "javax.faces.ViewState": "j_id1:j_id2"
        },
        extractors: [
            HTMLTitle, //"{\"full\": \"<title>InsuranceWeb: Home</title>\", \"groups\": [\"InsuranceWeb: Home\"]}"
            MSGError,
            LoggedInAs
        ],
        returnBody: true
    }).sendSync();

    
    //load.log(webResponse3.body);
    if (webResponse3.textCheck("message-error")) {
        // Login Failed !!!
        load.log(`Erreur : ${webResponse3.extractors.messageerror}`, load.LogLevel.error);
        load.log(`Iteration : ${load.config.runtime.iteration} ; UserName : [${username}]  ; Password :  [${password}]`);
        Login.stop(load.TransactionStatus.Failed);
    } else {
        // Login Succeed
        load.log(`Logged in as : ${webResponse3.extractors.loggedinas}`);
        Login.stop(load.TransactionStatus.Passed);
    }

});




load.action("Action2", async function () {

    load.log("Action2");
    
});


load.finalize(async function () {
});
