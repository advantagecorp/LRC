// This script was generated and reflects raw data. It is recommended to change this code to your required logic
load.initialize(async function () {
});

load.action("Action", async function () {

    load.WebRequest.defaults.returnBody = false;
    load.WebRequest.defaults.headers = {
        "Accept-Encoding": "gzip, deflate",
        "Accept-Language": "en-US,en;q=0.9",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
        "Pragma": "no-cache",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36"
    };

    const webResponse1 = new load.WebRequest({
        id: 1,
        url: "http://www.advantageonlineshopping.com/",
        method: "GET",
        headers: {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
            "Upgrade-Insecure-Requests": "1"
        },
        resources: [
            "http://www.advantageonlineshopping.com/css/images/review_Left_disabled.png",
            "http://www.advantageonlineshopping.com/css/images/reviewUser.png",
            "http://www.advantageonlineshopping.com/css/images/review_right.png",
            "http://www.advantageonlineshopping.com/catalog/api/v1/MostPopularComments",
            "http://www.advantageonlineshopping.com/catalog/fetchImage?image_id=2400",
            "http://www.advantageonlineshopping.com/catalog/fetchImage?image_id=2100",
            "http://www.advantageonlineshopping.com/catalog/fetchImage?image_id=2300",
            "http://www.advantageonlineshopping.com/catalog/fetchImage?image_id=2200",
            "http://www.advantageonlineshopping.com/css/images/Filter.png",
            "http://www.advantageonlineshopping.com/css/images/category_banner_2.png",
            "http://www.advantageonlineshopping.com/catalog/api/v1/categories/attributes",
            "http://www.advantageonlineshopping.com/css/images/Popular-item1.jpg",
            "http://www.advantageonlineshopping.com/css/images/Popular-item2.jpg",
            "http://www.advantageonlineshopping.com/css/images/Popular-item3.jpg",
            "http://www.advantageonlineshopping.com/css/images/Banner3.jpg",
            "http://www.advantageonlineshopping.com/css/images/Banner2.jpg",
            "http://www.advantageonlineshopping.com/css/images/Banner1.jpg",
            "http://www.advantageonlineshopping.com/css/images/linkedin.png",
            "http://www.advantageonlineshopping.com/css/images/twitter.png",
            "http://www.advantageonlineshopping.com/css/images/facebook.png",
            "http://www.advantageonlineshopping.com/css/images/GoUp.png",
            "http://www.advantageonlineshopping.com/css/images/chat_logo.png",
            "http://www.advantageonlineshopping.com/css/images/Special-offer.jpg",
            "http://www.advantageonlineshopping.com/catalog/fetchImage?image_id=1237",
            "http://www.advantageonlineshopping.com/catalog/fetchImage?image_id=1236",
            "http://www.advantageonlineshopping.com/catalog/fetchImage?image_id=1235",
            "http://www.advantageonlineshopping.com/catalog/fetchImage?image_id=1238",
            "http://www.advantageonlineshopping.com/catalog/fetchImage?image_id=1234",
            "http://www.advantageonlineshopping.com/css/images/arrow_right.png",
            "http://www.advantageonlineshopping.com/catalog/api/v1/deals/search?dealOfTheDay=true",
            "http://www.advantageonlineshopping.com/catalog/api/v1/categories",
            "http://www.advantageonlineshopping.com/css/images/closeDark.png",
            "http://www.advantageonlineshopping.com/css/images/logo.png",
            "http://www.advantageonlineshopping.com/catalog/api/v1/DemoAppConfig/parameters/by_tool/ALL",
            "http://www.advantageonlineshopping.com/catalog/api/v1/DemoAppConfig/parameters/by_tool/ALL",
            "http://www.advantageonlineshopping.com/catalog/api/v1/categories/all_data",
            "http://www.advantageonlineshopping.com/services.properties",
            "http://www.advantageonlineshopping.com/main.min.js",
            "http://www.advantageonlineshopping.com/vendor/requirejs/require.js",
            "http://www.advantageonlineshopping.com/css/images/Down_arrow.svg",
            "http://www.advantageonlineshopping.com/css/main.min.css"
        ]
    }).sendSync();

    const webResponse2 = new load.WebRequest({
        id: 2,
        url: "http://www.advantageonlineshopping.com/accountservice/GetAccountConfigurationRequest",
        method: "POST",
        headers: {
            "Content-Type": "text/xml; charset=UTF-8",
            "Origin": "http://www.advantageonlineshopping.com",
            "Referer": "http://www.advantageonlineshopping.com/",
            "X-Requested-With": "XMLHttpRequest",
            "Accept": "application/xml, text/xml, */*; q=0.01",
            "SOAPAction": "com.advantage.online.store.accountserviceGetAccountConfigurationRequest"
        },
        body: `<?xml version="1.0" encoding="UTF-8"?>        <soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
            <soap:Body>
                <GetAccountConfigurationRequest xmlns="com.advantage.online.store.accountservice"></GetAccountConfigurationRequest>
            </soap:Body>
        </soap:Envelope>`
    }).sendSync();

    const webResponse3 = new load.WebRequest({
        id: 3,
        url: "http://www.advantageonlineshopping.com/accountservice/GetAccountConfigurationRequest",
        method: "POST",
        headers: {
            "Origin": "http://www.advantageonlineshopping.com",
            "X-Requested-With": "XMLHttpRequest",
            "Referer": "http://www.advantageonlineshopping.com/",
            "Content-Type": "text/xml; charset=UTF-8",
            "Accept": "application/xml, text/xml, */*; q=0.01",
            "SOAPAction": "com.advantage.online.store.accountserviceGetAccountConfigurationRequest"
        },
        body: `<?xml version="1.0" encoding="UTF-8"?>        <soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
            <soap:Body>
                <GetAccountConfigurationRequest xmlns="com.advantage.online.store.accountservice"></GetAccountConfigurationRequest>
            </soap:Body>
        </soap:Envelope>`
    }).sendSync();

    const webResponse4 = new load.WebRequest({
        id: 4,
        url: "http://www.advantageonlineshopping.com/app/tempFiles/popularProducts.json",
        method: "GET",
        headers: {
            "Referer": "http://www.advantageonlineshopping.com/",
            "Accept": "application/json, text/plain, */*"
        }
    }).sendSync();

    const webResponse5 = new load.WebRequest({
        id: 5,
        url: "http://www.advantageonlineshopping.com/app/views/home-page.html",
        method: "GET",
        headers: {
            "Referer": "http://www.advantageonlineshopping.com/",
            "Accept": "text/html"
        }
    }).sendSync();

    const webResponse6 = new load.WebRequest({
        id: 6,
        url: "http://www.advantageonlineshopping.com/app/views/category-page.html",
        method: "GET",
        headers: {
            "Accept": "text/html",
            "Referer": "http://www.advantageonlineshopping.com/"
        }
    }).sendSync();

    const webResponse7 = new load.WebRequest({
        id: 7,
        url: "http://www.advantageonlineshopping.com/app/views/product-page.html",
        method: "GET",
        headers: {
            "Accept": "text/html",
            "Referer": "http://www.advantageonlineshopping.com/"
        }
    }).sendSync();
});

load.finalize(async function () {
});
