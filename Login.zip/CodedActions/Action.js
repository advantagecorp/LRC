(function() {
	"use strict";

	function actionAction() {
		// Navigate to "https://www.dropbox.com/?landing=dbv2"
		TCS.browser.navigate({
			"Location": TCS.argType.JSArg("\"https://www.dropbox.com/?landing=dbv2\"")
		});
		// Click on Sign in link
		TCS.object.tcManaged.signinObject.click({
			"X Coordinate": 37,
			"Y Coordinate": 19
		});
		// Click on Email emailbox
		TCS.object.tcManaged.emailObject.click({
			"X Coordinate": 129,
			"Y Coordinate": 13
		});
		// Type rodolfo.otero@microfocus.com in Email emailbox
		TCS.object.tcManaged.emailObject.type({
			"Value": "rodolfo.otero@microfocus.com"
		});
		// Type ********** in Password passwordbox
		TCS.object.tcManaged.passwordObject.type({
			"Value": TCS.argType.Base64Arg("UFdAd29yazEyMw==")
		});
		// Click on onRemember me 
		TCS.object.tcManaged.onRemembermeObject.click({
			"X Coordinate": 14,
			"Y Coordinate": 27
		});
		// Click on Remember me checkbox
		TCS.object.tcManaged.remembermeObject.click({
			"X Coordinate": 6,
			"Y Coordinate": 8
		});
		TCS.transaction.start("LoginToDropbox");
		// Click on Sign in button
		TCS.object.tcManaged.signinObject_2.click({
			"X Coordinate": 37,
			"Y Coordinate": 14
		});
		TCS.transaction.end("LoginToDropbox", "Auto");
	}
	actionAction();

})();