//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action()
{
	lr_start_transaction("Transaction 1");
	truclient_step("1", "Navigate to 'http://www.w3.org/'", "snapshot=Action_1.inf");
	lr_end_transaction("Transaction 1",0);
	lr_start_transaction("Transaction 2");
	truclient_step("2", "Click on Standards link", "snapshot=Action_2.inf");
	lr_end_transaction("Transaction 2",0);
	lr_start_transaction("Transaction 3");
	truclient_step("3", "Click on Participate link", "snapshot=Action_3.inf");
	lr_end_transaction("Transaction 3",0);
	lr_start_transaction("Transaction 4");
	truclient_step("4", "Click on Membership link", "snapshot=Action_4.inf");
	lr_end_transaction("Transaction 4",0);
	lr_start_transaction("Transaction 5");
	truclient_step("5", "Click on About W3C link", "snapshot=Action_5.inf");
	lr_end_transaction("Transaction 5",0);
	truclient_step("6", "Click on Contact link", "snapshot=Action_6.inf");

	return 0;
}
